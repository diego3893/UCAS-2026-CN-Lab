#define _GNU_SOURCE
#include "tcp.h"
#include "tcp_hash.h"
#include "tcp_sock.h"
#include "tcp_timer.h"
#include "ip.h"
#include "rtable.h"
#include "log.h"

// TCP socks should be hashed into table for later lookup: Those which
// occupy a port (either by *bind* or *connect*) should be hashed into
// bind_table, those which listen for incoming connection request should be
// hashed into listen_table, and those of established connections should
// be hashed into established_table.

/* 全局递归锁串行化应用、收包和定时器；阻塞等待前必须释放。 */
pthread_mutex_t tcp_lock = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
struct tcp_hash_table tcp_sock_table;
#define tcp_established_sock_table	tcp_sock_table.established_table
#define tcp_listen_sock_table		tcp_sock_table.listen_table
#define tcp_bind_sock_table			tcp_sock_table.bind_table

void tcp_set_state(struct tcp_sock *tsk, int state)
{
	log(DEBUG, IP_FMT":%hu switch state, from %s to %s.", \
			HOST_IP_FMT_STR(tsk->sk_sip), tsk->sk_sport, \
			tcp_state_str[tsk->state], tcp_state_str[state]);
	tsk->state = state;
}

// init tcp hash table and tcp timer
void init_tcp_stack()
{
	for (int i = 0; i < TCP_HASH_SIZE; i++)
		init_list_head(&tcp_established_sock_table[i]);

	for (int i = 0; i < TCP_HASH_SIZE; i++)
		init_list_head(&tcp_listen_sock_table[i]);

	for (int i = 0; i < TCP_HASH_SIZE; i++)
		init_list_head(&tcp_bind_sock_table[i]);

	pthread_t timer;
	pthread_create(&timer, NULL, tcp_timer_thread, NULL);
}

// allocate tcp sock, and initialize all the variables that can be determined
// now
struct tcp_sock *alloc_tcp_sock()
{
	struct tcp_sock *tsk = malloc(sizeof(struct tcp_sock));

	memset(tsk, 0, sizeof(struct tcp_sock));

	/* 初始引用属于应用，或尚未accept的父队列。 */
	tsk->ref_cnt = 1;
	init_list_head(&tsk->hash_list);
	init_list_head(&tsk->bind_hash_list);
	init_list_head(&tsk->timewait.list);
	init_list_head(&tsk->retrans_timer.list);
	init_list_head(&tsk->send_buf);
	init_list_head(&tsk->rcv_ofo_buf);
	tsk->state = TCP_CLOSED;
	tsk->rcv_wnd = TCP_DEFAULT_WINDOW;

	init_list_head(&tsk->list);
	init_list_head(&tsk->listen_queue);
	init_list_head(&tsk->accept_queue);

	tsk->rcv_buf = alloc_ring_buffer(tsk->rcv_wnd);

	tsk->wait_connect = alloc_wait_struct();
	tsk->wait_accept = alloc_wait_struct();
	tsk->wait_recv = alloc_wait_struct();
	tsk->wait_send = alloc_wait_struct();

	return tsk;
}

// release all the resources of tcp sock
//
// To make the stack run safely, each time the tcp sock is refered (e.g. hashed), 
// the ref_cnt is increased by 1. each time free_tcp_sock is called, the ref_cnt
// is decreased by 1, and release the resources practically if ref_cnt is
// decreased to zero.
void free_tcp_sock(struct tcp_sock *tsk){
	/* 仅最后一个所有者释放对象，避免表项和定时器悬空。 */
	if(--tsk->ref_cnt > 0){ return; }
	struct synch_wait *waits[] = {tsk->wait_connect, tsk->wait_accept, tsk->wait_recv, tsk->wait_send};
	for(int i=0; i<4; ++i){
		pthread_cond_destroy(&waits[i]->cond);
		pthread_mutex_destroy(&waits[i]->lock);
		free_wait_struct(waits[i]);
	}
	free_ring_buffer(tsk->rcv_buf);
	free(tsk);
}

// lookup tcp sock in established_table with key (saddr, daddr, sport, dport)
struct tcp_sock *tcp_sock_lookup_established(u32 saddr, u32 daddr, u16 sport, u16 dport){
	/* 完整四元组区分同一个监听端口上的不同连接。 */
	int hash = tcp_hash_function(saddr, daddr, sport, dport);
	struct tcp_sock *tsk;
	list_for_each_entry(tsk, &tcp_established_sock_table[hash], hash_list){
		if(tsk->sk_sip==saddr && tsk->sk_dip==daddr && tsk->sk_sport==sport && tsk->sk_dport==dport){ return tsk; }
	}
	return NULL;
}

// lookup tcp sock in listen_table with key (sport)
//
// In accordance with BSD socket, saddr is in the argument list, but never used.
struct tcp_sock *tcp_sock_lookup_listen(u32 saddr, u16 sport){
	/* bind使用通配地址，监听阶段只按本地端口查找。 */
	struct tcp_sock *tsk;
	int hash = tcp_hash_function(0, 0, sport, 0);
	list_for_each_entry(tsk, &tcp_listen_sock_table[hash], hash_list){
		if(tsk->sk_sport == sport){ return tsk; }
	}
	return NULL;
}

// lookup tcp sock in both established_table and listen_table
struct tcp_sock *tcp_sock_lookup(struct tcp_cb *cb)
{
	u32 saddr = cb->daddr,
		daddr = cb->saddr;
	u16 sport = cb->dport,
		dport = cb->sport;

	struct tcp_sock *tsk = tcp_sock_lookup_established(saddr, daddr, sport, dport);
	if (!tsk)
		tsk = tcp_sock_lookup_listen(saddr, sport);

	return tsk;
}

// hash tcp sock into bind_table, using sport as the key
static int tcp_bind_hash(struct tcp_sock *tsk)
{
	int bind_hash_value = tcp_hash_function(0, 0, tsk->sk_sport, 0);
	struct list_head *list = &tcp_bind_sock_table[bind_hash_value];
	list_add_head(&tsk->bind_hash_list, list);

	tsk->ref_cnt += 1;

	return 0;
}

// unhash the tcp sock from bind_table
void tcp_bind_unhash(struct tcp_sock *tsk)
{
	if (!list_empty(&tsk->bind_hash_list)) {
		list_delete_entry(&tsk->bind_hash_list);
		init_list_head(&tsk->bind_hash_list);
		free_tcp_sock(tsk);
	}
}

// lookup bind_table to check whether sport is in use
static int tcp_port_in_use(u16 sport)
{
	int value = tcp_hash_function(0, 0, sport, 0);
	struct list_head *list = &tcp_bind_sock_table[value];
	struct tcp_sock *tsk;
	list_for_each_entry(tsk, list, bind_hash_list) {
		if (tsk->sk_sport == sport)
			return 1;
	}

	return 0;
}

// find a free port by looking up bind_table
static u16 tcp_get_port()
{
	for (u16 port = PORT_MIN; port < PORT_MAX; port++) {
		if (!tcp_port_in_use(port))
			return port;
	}

	return 0;
}

// tcp sock tries to use port as its source port
static int tcp_sock_set_sport(struct tcp_sock *tsk, u16 port)
{
	if ((port && tcp_port_in_use(port)) ||
			(!port && !(port = tcp_get_port())))
		return -1;

	tsk->sk_sport = port;

	tcp_bind_hash(tsk);

	return 0;
}

// hash tcp sock into either established_table or listen_table according to its
// TCP_STATE
int tcp_hash(struct tcp_sock *tsk)
{
	struct list_head *list;
	int hash;

	if (tsk->state == TCP_CLOSED)
		return -1;

	if (tsk->state == TCP_LISTEN) {
		hash = tcp_hash_function(0, 0, tsk->sk_sport, 0);
		list = &tcp_listen_sock_table[hash];
	}
	else {
		int hash = tcp_hash_function(tsk->sk_sip, tsk->sk_dip, \
				tsk->sk_sport, tsk->sk_dport); 
		list = &tcp_established_sock_table[hash];

		struct tcp_sock *tmp;
		list_for_each_entry(tmp, list, hash_list) {
			if (tsk->sk_sip == tmp->sk_sip &&
					tsk->sk_dip == tmp->sk_dip &&
					tsk->sk_sport == tmp->sk_sport &&
					tsk->sk_dport == tmp->sk_dport)
				return -1;
		}
	}

	list_add_head(&tsk->hash_list, list);
	tsk->ref_cnt += 1;

	return 0;
}

// unhash tcp sock from established_table or listen_table
void tcp_unhash(struct tcp_sock *tsk)
{
	if (!list_empty(&tsk->hash_list)) {
		list_delete_entry(&tsk->hash_list);
		init_list_head(&tsk->hash_list);
		free_tcp_sock(tsk);
	}
}

// XXX: skaddr here contains network-order variables
int tcp_sock_bind(struct tcp_sock *tsk, struct sock_addr *skaddr)
{
	int err = 0;

	// omit the ip address, and only bind the port
	pthread_mutex_lock(&tcp_lock);
	err = tcp_sock_set_sport(tsk, ntohs(skaddr->port));
	pthread_mutex_unlock(&tcp_lock);

	return err;
}

// connect to the remote tcp sock specified by skaddr
//
// XXX: skaddr here contains network-order variables
// 1. initialize the four key tuple (sip, sport, dip, dport);
// 2. hash the tcp sock into bind_table;
// 3. send SYN packet, switch to TCP_SYN_SENT state, wait for the incoming
//    SYN packet by sleep on wait_connect;
// 4. if the SYN packet of the peer arrives, this function is notified, which
//    means the connection is established.
int tcp_sock_connect(struct tcp_sock *tsk, struct sock_addr *skaddr){
	/* 由目的路由选择源地址，先入表再发SYN，避免快速回复找不到连接。 */
	pthread_mutex_lock(&tcp_lock);
	rt_entry_t *route = longest_prefix_match(ntohl(skaddr->ip));
	if(!route || tcp_sock_set_sport(tsk, 0)<0){
		pthread_mutex_unlock(&tcp_lock); return -1;
	}
	tsk->sk_sip = route->iface->ip;
	tsk->sk_dip = ntohl(skaddr->ip);
	tsk->sk_dport = ntohs(skaddr->port);
	tsk->iss = tcp_new_iss();
	tsk->snd_una = tsk->snd_nxt = tsk->iss;
	tcp_set_state(tsk, TCP_SYN_SENT);
	tcp_hash(tsk);
	tcp_send_control_packet(tsk, TCP_SYN);
	while(tsk->state == TCP_SYN_SENT){
		pthread_mutex_unlock(&tcp_lock);
		sleep_on(tsk->wait_connect);
		pthread_mutex_lock(&tcp_lock);
	}
	int result = tsk->state==TCP_ESTABLISHED ? 0 : -1;
	pthread_mutex_unlock(&tcp_lock);
	return result;
}

// set backlog (the maximum number of pending connection requst), switch the
// TCP_STATE, and hash the tcp sock into listen_table
int tcp_sock_listen(struct tcp_sock *tsk, int backlog){
	/* 监听socket与连接socket使用不同哈希表。 */
	pthread_mutex_lock(&tcp_lock);
	if(tsk->state!=TCP_CLOSED || list_empty(&tsk->bind_hash_list)){
		pthread_mutex_unlock(&tcp_lock); return -1;
	}
	tsk->backlog = backlog<1 ? 1 : (backlog>TCP_MAX_BACKLOG ? TCP_MAX_BACKLOG : backlog);
	tcp_set_state(tsk, TCP_LISTEN);
	int result = tcp_hash(tsk);
	pthread_mutex_unlock(&tcp_lock);
	return result;
}

// check whether the accept queue is full
int tcp_sock_accept_queue_full(struct tcp_sock *tsk)
{
	if (tsk->accept_backlog >= tsk->backlog) {
		log(ERROR, "tcp accept queue (%d) is full.", tsk->accept_backlog);
		return 1;
	}

	return 0;
}

// push the tcp sock into accept_queue
void tcp_sock_accept_enqueue(struct tcp_sock *tsk)
{
	if (!list_empty(&tsk->list))
		list_delete_entry(&tsk->list);
	list_add_tail(&tsk->list, &tsk->parent->accept_queue);
	tsk->parent->accept_backlog += 1;
}

// pop the first tcp sock of the accept_queue
struct tcp_sock *tcp_sock_accept_dequeue(struct tcp_sock *tsk)
{
	struct tcp_sock *new_tsk = list_entry(tsk->accept_queue.next, struct tcp_sock, list);
	list_delete_entry(&new_tsk->list);
	init_list_head(&new_tsk->list);
	tsk->accept_backlog -= 1;

	return new_tsk;
}

// if accept_queue is not emtpy, pop the first tcp sock and accept it,
// otherwise, sleep on the wait_accept for the incoming connection requests
struct tcp_sock *tcp_sock_accept(struct tcp_sock *tsk){
	/* 循环检查条件，notified可保留先于sleep到来的通知。 */
	pthread_mutex_lock(&tcp_lock);
	while(list_empty(&tsk->accept_queue) && tsk->state==TCP_LISTEN){
		pthread_mutex_unlock(&tcp_lock);
		sleep_on(tsk->wait_accept);
		pthread_mutex_lock(&tcp_lock);
	}
	struct tcp_sock *child = NULL;
	if(!list_empty(&tsk->accept_queue)){
		child = tcp_sock_accept_dequeue(tsk);
		child->parent = NULL;
	}
	pthread_mutex_unlock(&tcp_lock);
	return child;
}

// close the tcp sock, by releasing the resources, sending FIN/RST packet
// to the peer, switching TCP_STATE to closed
void tcp_sock_close(struct tcp_sock *tsk){
	/* close只启动关闭；hash和TIME_WAIT引用继续维持连接生命周期。 */
	if(!tsk){ return; }
	pthread_mutex_lock(&tcp_lock);
	if(tsk->state==TCP_ESTABLISHED || tsk->state==TCP_SYN_RECV){
		tcp_set_state(tsk, TCP_FIN_WAIT_1);
		tcp_send_control_packet(tsk, TCP_FIN|TCP_ACK);
	}
	else if(tsk->state == TCP_CLOSE_WAIT){
		tcp_set_state(tsk, TCP_LAST_ACK);
		tcp_send_control_packet(tsk, TCP_FIN|TCP_ACK);
	}
	else if(tsk->state==TCP_LISTEN || tsk->state==TCP_SYN_SENT || tsk->state==TCP_CLOSED){
		/* 关闭监听时，队列中尚未交给应用的子连接也必须清理。 */
		struct tcp_sock *child, *next;
		list_for_each_entry_safe(child, next, &tsk->listen_queue, list){ tcp_finish(child); }
		list_for_each_entry_safe(child, next, &tsk->accept_queue, list){ tcp_finish(child); }
		tcp_finish(tsk);
	}
	free_tcp_sock(tsk);
	pthread_mutex_unlock(&tcp_lock);
}

/* 调用者持锁且持有引用；关闭时分别归还哈希、绑定和父队列引用。 */
void tcp_finish(struct tcp_sock *tsk){
	/* 清理多个所有者前持有临时引用，防止最后一次摘表后继续访问。 */
	tsk->ref_cnt++;
	tcp_set_state(tsk, TCP_CLOSED);
	wake_up(tsk->wait_connect);
	wake_up(tsk->wait_accept);
	wake_up(tsk->wait_recv);
	if(tsk->parent){
		if(tsk->parent->accept_backlog>0 && !list_empty(&tsk->list)){
			/* 只在accept队列中减少计数。 */
			struct tcp_sock *entry;
			list_for_each_entry(entry, &tsk->parent->accept_queue, list){
				if(entry == tsk){ tsk->parent->accept_backlog--; break; }
			}
		}
		list_delete_entry(&tsk->list);
		init_list_head(&tsk->list);
		tsk->parent = NULL;
		free_tcp_sock(tsk);
	}
	tcp_unhash(tsk);
	tcp_bind_unhash(tsk);
	free_tcp_sock(tsk);
}
